import os
import numpy as np
import cv2
import onnxruntime as ort
from sklearn.metrics import confusion_matrix, accuracy_score, precision_score, recall_score

# ==============================
# CONFIG
# ==============================
MODEL_PATH = "Model/Ol-Digoad_IESA.onnx"
DATASET_PATH = "hackathon_test_dataset"
LABELS_FILE = "labels.txt"
IMG_SIZE = 224

# 9-class mapped labels (hackathon-aligned)
MAPPED_LABELS = [
    "bridge", "clean", "cmp", "crack", "ler", "open",
    "particle_contamination", "via", "other"
]

# ==============================
# LOAD MODEL LABELS (12)
# ==============================
with open(LABELS_FILE, "r", encoding="utf-8") as f:
    model_labels = [line.strip() for line in f if line.strip()]

print("Model Labels (12):", model_labels)

# ==============================
# LOAD ONNX MODEL
# ==============================
session = ort.InferenceSession(MODEL_PATH, providers=["CPUExecutionProvider"])
input_meta = session.get_inputs()[0]
input_name = input_meta.name
print("INPUT NAME:", input_name)
print("INPUT SHAPE:", input_meta.shape)  # should be [?,224,224,3]

# ==============================
# PREPROCESS -> (1,224,224,3) NHWC
# ==============================
def preprocess(img_path: str) -> np.ndarray:
    img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        raise FileNotFoundError(f"Cannot read image: {img_path}")

    img = cv2.resize(img, (IMG_SIZE, IMG_SIZE))
    img = cv2.cvtColor(img, cv2.COLOR_GRAY2RGB)  # (224,224,3)
    img = img.astype(np.float32) / 255.0
    img = img[None, :, :, :]  # (1,224,224,3)
    return img

# ==============================
# MAP PREDICTION (12 -> 9)
# ==============================
def map_pred_label(pred_label: str) -> str:
    # Keep these 8 classes
    if pred_label in MAPPED_LABELS and pred_label != "other":
        return pred_label
    # All remaining model classes -> other
    return "other"

def normalize_true_label(folder_name: str) -> str:
    # Your folders are already renamed, but this is a safety net
    name = folder_name.strip().lower()
    if name in MAPPED_LABELS:
        return name
    return "other"

# ==============================
# RUN PREDICTIONS (collect both raw + mapped)
# ==============================
y_true_raw = []
y_pred_raw = []

y_true_map = []
y_pred_map = []

for folder in sorted(os.listdir(DATASET_PATH)):
    class_folder = os.path.join(DATASET_PATH, folder)
    if not os.path.isdir(class_folder):
        continue

    true_label_folder = folder  # raw true label from folder name
    true_label_mapped = normalize_true_label(folder)

    for img_name in sorted(os.listdir(class_folder)):
        if not img_name.lower().endswith((".png", ".jpg", ".jpeg", ".bmp", ".tif", ".tiff")):
            continue

        img_path = os.path.join(class_folder, img_name)
        x = preprocess(img_path)

        out = session.run(None, {input_name: x})[0]  # (1,num_classes)
        pred_idx = int(np.argmax(out, axis=1)[0])
        pred_label_12 = model_labels[pred_idx]

        # RAW
        y_true_raw.append(true_label_folder)
        y_pred_raw.append(pred_label_12)

        # MAPPED
        y_true_map.append(true_label_mapped)
        y_pred_map.append(map_pred_label(pred_label_12))

print("\nTotal images evaluated:", len(y_true_raw))

# ==============================
# RAW 12-CLASS METRICS
# ==============================
print("\n==============================")
print("RAW CONFUSION MATRIX (12-class)")
print("Rows=True labels from dataset folders, Cols=Model labels")
print("Labels (cols):", model_labels)
print("==============================")

cm_raw = confusion_matrix(y_true_raw, y_pred_raw, labels=model_labels)
print(cm_raw)

acc_raw = accuracy_score(y_true_raw, y_pred_raw)
prec_raw = precision_score(y_true_raw, y_pred_raw, average="macro", zero_division=0)
rec_raw = recall_score(y_true_raw, y_pred_raw, average="macro", zero_division=0)

print("\nRAW METRICS (macro average)")
print(f"Accuracy : {acc_raw:.4f}")
print(f"Precision: {prec_raw:.4f}")
print(f"Recall   : {rec_raw:.4f}")

# ==============================
# MAPPED 9-CLASS METRICS
# ==============================
print("\n==============================")
print("MAPPED CONFUSION MATRIX (9-class)")
print("Rows=True, Cols=Pred")
print("Labels:", MAPPED_LABELS)
print("==============================")

cm_map = confusion_matrix(y_true_map, y_pred_map, labels=MAPPED_LABELS)
print(cm_map)

acc_map = accuracy_score(y_true_map, y_pred_map)
prec_map = precision_score(y_true_map, y_pred_map, average="macro", zero_division=0)
rec_map = recall_score(y_true_map, y_pred_map, average="macro", zero_division=0)

print("\nMAPPED METRICS (macro average)")
print(f"Accuracy : {acc_map:.4f}")
print(f"Precision: {prec_map:.4f}")
print(f"Recall   : {rec_map:.4f}")
